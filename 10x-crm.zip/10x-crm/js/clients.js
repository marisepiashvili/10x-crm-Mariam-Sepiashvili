/**
 * clients.js — P4
 * The product's core screen: load, search, filter, sort, add, delete,
 * inline status change, and a details modal with notes + a follow-up reminder.
 */

let allClients = [];
let viewState = { status: 'All', search: '', sort: 'newest' };

/* ---------------- Loading & rendering ---------------- */

async function initClientsPage() {
  const area = document.getElementById('clients-area');
  area.innerHTML = '<div class="state-msg">Loading clients...</div>';

  try {
    const { clients } = await loadClients();
    allClients = clients;
    renderClientList();
  } catch (err) {
    area.innerHTML = `
      <div class="state-msg">
        Could not load clients. Check your connection and try again.
        <div><button class="btn btn-ghost retry-btn" id="retry-load" type="button">Retry</button></div>
      </div>`;
    document.getElementById('retry-load').addEventListener('click', initClientsPage);
  }
}

function statusBadgeClass(status) {
  return 'st-' + status.toLowerCase();
}

function renderClientList() {
  const area = document.getElementById('clients-area');
  const visible = getVisibleClients(allClients, viewState);

  if (visible.length === 0) {
    area.innerHTML = '<div class="state-msg">No clients found.</div>';
    return;
  }

  const grid = document.createElement('div');
  grid.className = 'client-grid';

  visible.forEach((client) => {
    const card = document.createElement('div');
    card.className = 'client-card';
    card.dataset.id = client.id;

    card.innerHTML = `
      <div class="client-top">
        <img src="${client.image}" alt="">
        <div style="min-width:0;">
          <div class="client-name">${escapeHtml(client.name)}</div>
          <div class="client-company">${escapeHtml(client.company || '—')}</div>
          <div class="client-email">${escapeHtml(client.email)}</div>
        </div>
      </div>
      <div class="client-bottom">
        <span class="deal-value">${formatCurrency(client.dealValue)}</span>
        <div class="client-actions">
          <select class="status-select" data-id="${client.id}">
            ${['Lead', 'Contacted', 'Won', 'Lost'].map(
              (s) => `<option value="${s}" ${s === client.status ? 'selected' : ''}>${s}</option>`
            ).join('')}
          </select>
          <button class="delete-btn" data-id="${client.id}" type="button" title="Delete">&times;</button>
        </div>
      </div>
    `;

    // Card click -> details modal, but not when clicking the interactive controls
    card.addEventListener('click', (e) => {
      if (e.target.closest('select') || e.target.closest('button')) return;
      openDetailModal(client.id);
    });

    grid.appendChild(card);
  });

  area.innerHTML = '';
  area.appendChild(grid);

  // Wire per-card controls
  area.querySelectorAll('.status-select').forEach((select) => {
    select.addEventListener('click', (e) => e.stopPropagation());
    select.addEventListener('change', (e) => onStatusChange(e.target.dataset.id, e.target.value));
  });
  area.querySelectorAll('.delete-btn').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      onDeleteClient(btn.dataset.id);
    });
  });
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str == null ? '' : str;
  return div.innerHTML;
}

/* ---------------- Toolbar wiring ---------------- */

function wireToolbar() {
  document.getElementById('search-input').addEventListener('input', (e) => {
    viewState.search = e.target.value;
    renderClientList();
  });

  document.querySelectorAll('#filter-chips .chip').forEach((chip) => {
    chip.addEventListener('click', () => {
      document.querySelectorAll('#filter-chips .chip').forEach((c) => c.classList.remove('active'));
      chip.classList.add('active');
      viewState.status = chip.dataset.status;
      renderClientList();
    });
  });

  document.getElementById('sort-select').addEventListener('change', (e) => {
    viewState.sort = e.target.value;
    renderClientList();
  });
}

/* ---------------- Status change (P4.6) ---------------- */

function onStatusChange(id, newStatus) {
  const client = allClients.find((c) => String(c.id) === String(id));
  if (!client) return;
  client.status = newStatus;
  saveClients(allClients);
  renderClientList();
}

/* ---------------- Delete (P4.5) ---------------- */

async function onDeleteClient(id) {
  const confirmed = confirm('Delete this client? This cannot be undone.');
  if (!confirmed) return;

  try {
    await fetch(`${API_BASE}/users/${id}`, { method: 'DELETE' });
  } catch (err) {
    // DummyJSON simulates deletes; a network hiccup or a 404 for
    // locally-added clients is expected and does not block local removal.
  } finally {
    allClients = allClients.filter((c) => String(c.id) !== String(id));
    saveClients(allClients);
    renderClientList();
    showToast('Client deleted');
  }
}

/* ---------------- Add Client modal (P4.4) ---------------- */

function wireAddModal() {
  const backdrop = document.getElementById('add-modal-backdrop');
  const openBtn = document.getElementById('open-add-client');
  const closeBtn = document.getElementById('add-modal-close');
  const form = document.getElementById('add-client-form');

  const open = () => backdrop.classList.add('open');
  const close = () => {
    backdrop.classList.remove('open');
    form.reset();
    ['name', 'clientEmail', 'phone', 'company', 'dealValue'].forEach((id) => setFieldError(id, ''));
  };

  openBtn.addEventListener('click', open);
  closeBtn.addEventListener('click', close);
  backdrop.addEventListener('click', (e) => { if (e.target === backdrop) close(); });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('clientEmail').value;
    const phone = document.getElementById('phone').value;
    const company = document.getElementById('company').value;
    const dealValueRaw = document.getElementById('dealValue').value;
    const status = document.getElementById('status').value;

    const fieldIds = ['name', 'clientEmail', 'phone', 'company', 'dealValue'];
    fieldIds.forEach((id) => setFieldError(id, ''));
    let hasError = false;

    if (name.trim().length < 3) {
      setFieldError('name', 'Name must be at least 3 characters');
      hasError = true;
    }

    const atIndex = email.indexOf('@');
    const validFormat = atIndex > 0 && email.indexOf('.', atIndex) > atIndex;
    if (!validFormat) {
      setFieldError('clientEmail', 'Please enter a valid email address');
      hasError = true;
    } else if (allClients.some((c) => c.email.toLowerCase() === email.trim().toLowerCase())) {
      setFieldError('clientEmail', 'A client with this email already exists');
      hasError = true;
    }

    if (phone.trim() !== '' && phone.trim().length < 6) {
      setFieldError('phone', 'Phone number looks too short');
      hasError = true;
    }

    const dealValue = Number(dealValueRaw);
    if (dealValueRaw.trim() === '' || isNaN(dealValue) || dealValue <= 0) {
      setFieldError('dealValue', 'Deal value must be a positive number');
      hasError = true;
    }

    if (hasError) return;

    try {
      const response = await fetch(`${API_BASE}/users/add`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ firstName: name.trim() }),
      });
      const result = await response.json();

      const newClient = {
        id: result.id || Date.now(),
        name: name.trim(),
        email: email.trim().toLowerCase(),
        phone: phone.trim(),
        company: company.trim(),
        image: `https://dummyjson.com/icon/${encodeURIComponent(name.trim().split(' ')[0].toLowerCase())}/128`,
        status: status,
        dealValue: dealValue,
        notes: [],
        createdAt: new Date().toISOString(),
      };

      allClients.unshift(newClient);
      saveClients(allClients);
      renderClientList();
      close();
      showToast('Client added \u2713');
    } catch (err) {
      showToast('Could not add client. Please try again.', 'error');
    }
  });

  ['name', 'clientEmail', 'phone', 'dealValue'].forEach((id) => {
    document.getElementById(id).addEventListener('input', () => setFieldError(id, ''));
  });
}

/* ---------------- Details modal (P4.8) ---------------- */

function openDetailModal(id) {
  const client = allClients.find((c) => String(c.id) === String(id));
  if (!client) return;

  const backdrop = document.getElementById('detail-modal-backdrop');
  const content = document.getElementById('detail-modal-content');

  content.innerHTML = `
    <div class="modal-head">
      <h3>Client Details</h3>
      <button class="modal-close" id="detail-modal-close" type="button">&times;</button>
    </div>
    <div class="detail-top">
      <img src="${client.image}" alt="">
      <div>
        <div class="client-name">${escapeHtml(client.name)}</div>
        <div class="detail-meta">Client since ${new Date(client.createdAt).toLocaleDateString()}</div>
      </div>
    </div>
    <div class="detail-grid">
      <div><span>Company</span>${escapeHtml(client.company || '—')}</div>
      <div><span>Status</span><span class="badge ${statusBadgeClass(client.status)}">${client.status}</span></div>
      <div><span>Email</span>${escapeHtml(client.email)}</div>
      <div><span>Phone</span>${escapeHtml(client.phone || '—')}</div>
      <div style="grid-column:1 / -1;"><span>Deal Value</span>${formatCurrency(client.dealValue)}</div>
    </div>
    <h3 style="font-family:var(--font-display); font-size:15px; margin:0 0 8px;">Notes</h3>
    <div class="notes-list" id="notes-list"></div>
    <div class="note-add">
      <input type="text" id="note-input" placeholder="Write a note...">
      <button class="btn btn-ghost" id="add-note-btn" type="button">+ Add note</button>
    </div>
    <button class="btn btn-ghost" id="remind-btn" type="button" style="width:100%;">Remind me in 1 min</button>
  `;

  renderNotes(client);

  document.getElementById('detail-modal-close').addEventListener('click', closeDetailModal);
  backdrop.addEventListener('click', function backdropClose(e) {
    if (e.target === backdrop) {
      closeDetailModal();
      backdrop.removeEventListener('click', backdropClose);
    }
  });

  document.getElementById('add-note-btn').addEventListener('click', () => addNote(client.id));
  document.getElementById('note-input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') addNote(client.id);
  });

  document.getElementById('remind-btn').addEventListener('click', () => {
    showToast('Reminder set \u2713');
    setTimeout(() => showToast(`\u23F0 Follow up: ${client.name}`), 60000);
  });

  backdrop.classList.add('open');
}

function closeDetailModal() {
  document.getElementById('detail-modal-backdrop').classList.remove('open');
}

function renderNotes(client) {
  const list = document.getElementById('notes-list');
  if (!client.notes || client.notes.length === 0) {
    list.innerHTML = '<div class="note-empty">No notes yet.</div>';
    return;
  }
  const sorted = client.notes.slice().sort((a, b) => new Date(a.date) - new Date(b.date));
  list.innerHTML = sorted.map(
    (n) => `<div class="note-item">${escapeHtml(n.text)}<span class="ndate">${escapeHtml(n.date)}</span></div>`
  ).join('');
}

function addNote(clientId) {
  const input = document.getElementById('note-input');
  const text = input.value.trim();
  if (!text) return;

  const client = allClients.find((c) => String(c.id) === String(clientId));
  if (!client) return;

  client.notes = client.notes || [];
  client.notes.push({ text, date: new Date().toLocaleString() });
  saveClients(allClients);

  input.value = '';
  renderNotes(client);
}

/* ---------------- Init ---------------- */

document.addEventListener('DOMContentLoaded', () => {
  wireToolbar();
  wireAddModal();
  initClientsPage();
});
