/**
 * guard.js
 * Shared, page-agnostic logic:
 *  - Auth Guard (P0.1): protects private pages, redirects logged-in users away from public pages
 *  - Navigation wiring + active link + logout (P0.2)
 *  - Theme toggle, persisted in crm_theme (P0.3)
 *  - Toast notification helper (P0.4)
 */

const STORAGE_KEYS = {
  users: 'crm_users',
  session: 'crm_session',
  clients: 'crm_clients',
  theme: 'crm_theme',
};

const PROTECTED_PAGES = ['dashboard.html', 'clients.html', 'profile.html'];
const PUBLIC_PAGES = ['index.html', ''];

function getCurrentPage() {
  const path = window.location.pathname.split('/').pop();
  return path || 'index.html';
}

function getSession() {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.session);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function runAuthGuard() {
  const page = getCurrentPage();
  const session = getSession();

  if (PROTECTED_PAGES.includes(page) && !session) {
    window.location.href = 'index.html';
    return;
  }
  if (PUBLIC_PAGES.includes(page) && session) {
    window.location.href = 'dashboard.html';
  }
}

// Run the guard immediately (before paint) so protected content never flashes.
runAuthGuard();

/* ---------------- Theme ---------------- */

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  const toggleLabel = document.querySelector('[data-theme-label]');
  if (toggleLabel) toggleLabel.textContent = theme === 'dark' ? 'Dark' : 'Light';
}

function initTheme() {
  const saved = localStorage.getItem(STORAGE_KEYS.theme) || 'dark';
  applyTheme(saved);
}

function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme') || 'dark';
  const next = current === 'dark' ? 'light' : 'dark';
  localStorage.setItem(STORAGE_KEYS.theme, next);
  applyTheme(next);
}

initTheme();

/* ---------------- Shared form-field error helper ----------------
 * Used by every form on the site: signup, login, add-client, profile.
 * Expects markup: <div id="{id}-field" class="field"> ... <div id="{id}-error">
 */

function setFieldError(fieldId, message) {
  const wrap = document.getElementById(fieldId + '-field');
  const err = document.getElementById(fieldId + '-error');
  if (!wrap || !err) return;
  if (message) {
    wrap.classList.add('input-error');
    err.textContent = message;
  } else {
    wrap.classList.remove('input-error');
    err.textContent = '';
  }
}

/* ---------------- Toast ---------------- */

function showToast(message, type = 'success') {
  let stack = document.querySelector('.toast-stack');
  if (!stack) {
    stack = document.createElement('div');
    stack.className = 'toast-stack';
    document.body.appendChild(stack);
  }
  const toast = document.createElement('div');
  toast.className = 'toast' + (type === 'error' ? ' err' : '');
  toast.textContent = message;
  stack.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}

/* ---------------- Nav wiring (called on protected pages) ----------------
 * The sidebar markup lives in ONE place (buildSidebar) so dashboard.html,
 * clients.html and profile.html never duplicate it -- each just provides
 * an empty <div id="sidebar-root"></div>.
 */

function buildSidebar(activePage) {
  const links = [
    { key: 'dashboard.html', label: 'Dashboard' },
    { key: 'clients.html', label: 'Clients' },
    { key: 'profile.html', label: 'Profile' },
  ];

  const linksHtml = links
    .map(
      (l) => '<a class="nav-link' + (l.key === activePage ? ' active' : '') +
        '" href="' + l.key + '" data-page="' + l.key + '"><span class="dot"></span>' + l.label + '</a>'
    )
    .join('');

  return '' +
    '<a class="brand" href="dashboard.html"><span class="stamp">10X</span> 10X CRM</a>' +
    '<nav class="nav-links">' + linksHtml + '</nav>' +
    '<div class="sidebar-footer">' +
      '<button class="theme-toggle" data-theme-toggle type="button">' +
        '<span>Theme</span><span data-theme-label>Dark</span>' +
      '</button>' +
      '<button class="logout-btn" data-logout type="button">Log out</button>' +
    '</div>';
}

function wireAppShell() {
  const page = getCurrentPage();

  const root = document.getElementById('sidebar-root');
  if (root) {
    root.innerHTML = buildSidebar(page);
  }

  applyTheme(localStorage.getItem(STORAGE_KEYS.theme) || 'dark');

  const themeBtn = document.querySelector('[data-theme-toggle]');
  if (themeBtn) themeBtn.addEventListener('click', toggleTheme);

  const logoutBtn = document.querySelector('[data-logout]');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      localStorage.removeItem(STORAGE_KEYS.session);
      window.location.href = 'index.html';
    });
  }
}

/* ---------------- User store helpers (shared by auth.js / profile.js) ---------------- */

function getUsers() {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.users);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveUsers(users) {
  localStorage.setItem(STORAGE_KEYS.users, JSON.stringify(users));
}

document.addEventListener('DOMContentLoaded', () => {
  if (PROTECTED_PAGES.includes(getCurrentPage())) {
    wireAppShell();
  }
});
