/**
 * auth.js — Sign Up (P1) and Login (P2) logic.
 * Relies on getUsers/saveUsers/showToast from guard.js (loaded first).
 */

function clearAllErrors(fieldIds) {
  fieldIds.forEach((id) => setFieldError(id, ''));
}

/* ---------------- Sign Up (P1) ---------------- */

function initSignupForm() {
  const form = document.getElementById('signup-form');
  if (!form) return;

  form.addEventListener('submit', (event) => {
    event.preventDefault();

    const fullName = document.getElementById('fullName').value;
    const email = document.getElementById('email').value;
    const company = document.getElementById('company').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    const fieldIds = ['fullName', 'email', 'password', 'confirmPassword'];
    clearAllErrors(fieldIds);

    let hasError = false;
    const users = getUsers();
    const emailLower = email.trim().toLowerCase();

    // Full Name
    if (fullName.trim().length < 3) {
      setFieldError('fullName', 'Full name must be at least 3 characters');
      hasError = true;
    }

    // Email format
    const atIndex = email.indexOf('@');
    const validFormat = atIndex > 0 && email.indexOf('.', atIndex) > atIndex;
    if (!validFormat) {
      setFieldError('email', 'Please enter a valid email address');
      hasError = true;
    } else if (users.some((u) => u.email === emailLower)) {
      setFieldError('email', 'An account with this email already exists');
      hasError = true;
    }

    // Password
    const hasLetter = /[a-zA-Z]/.test(password);
    const hasDigit = /[0-9]/.test(password);
    if (password.length < 8 || !hasLetter || !hasDigit) {
      setFieldError('password', 'Password must be at least 8 characters and contain a letter and a number');
      hasError = true;
    }

    // Confirm password
    if (confirmPassword !== password) {
      setFieldError('confirmPassword', 'Passwords do not match');
      hasError = true;
    }

    if (hasError) return;

    const newUser = {
      id: Date.now(),
      fullName: fullName.trim(),
      email: emailLower,
      password: password,
      company: company.trim(),
      createdAt: new Date().toISOString(),
    };

    users.push(newUser);
    saveUsers(users);

    showToast('Account created successfully! Please log in.');
    setTimeout(() => {
      window.location.href = 'index.html';
    }, 1500);
  });

  // Clear a field's error as soon as it becomes valid again (live UX bonus)
  ['fullName', 'email', 'password', 'confirmPassword'].forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('input', () => setFieldError(id, ''));
  });
}

/* ---------------- Login (P2) ---------------- */

function initLoginForm() {
  const form = document.getElementById('login-form');
  if (!form) return;

  form.addEventListener('submit', (event) => {
    event.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const fieldIds = ['email', 'password'];
    clearAllErrors(fieldIds);

    let hasError = false;

    if (email.trim() === '') {
      setFieldError('email', 'Email is required');
      hasError = true;
    }
    if (password === '') {
      setFieldError('password', 'Password is required');
      hasError = true;
    }
    if (hasError) return;

    const users = getUsers();
    const emailLower = email.trim().toLowerCase();
    const match = users.find((u) => u.email === emailLower && u.password === password);

    const generalError = document.getElementById('login-general-error');
    if (!match) {
      if (generalError) {
        generalError.textContent = 'Invalid email or password';
        generalError.style.display = 'block';
      }
      return;
    }
    if (generalError) generalError.style.display = 'none';

    const session = {
      userId: match.id,
      email: match.email,
      loginAt: new Date().toISOString(),
    };
    localStorage.setItem(STORAGE_KEYS.session, JSON.stringify(session));
    window.location.href = 'dashboard.html';
  });

  ['email', 'password'].forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('input', () => {
      setFieldError(id, '');
      const generalError = document.getElementById('login-general-error');
      if (generalError) generalError.style.display = 'none';
    });
  });
}

document.addEventListener('DOMContentLoaded', () => {
  initSignupForm();
  initLoginForm();
});
