/**
 * dashboard.js — P3
 * Greeting + live clock, 4 stat cards, Pipeline Overview, Recent Clients (top 5).
 */

const STATUS_ORDER = ['Lead', 'Contacted', 'Won', 'Lost'];
const STATUS_COLOR_VAR = {
  Lead: 'var(--amber)',
  Contacted: 'var(--blue)',
  Won: 'var(--accent)',
  Lost: 'var(--rose)',
};

function renderGreeting() {
  const session = getSession();
  const users = getUsers();
  const me = users.find((u) => u.id === session.userId);
  const firstName = me ? me.fullName.split(' ')[0] : 'there';
  document.getElementById('greeting').textContent = `Welcome back, ${firstName}!`;
}

function tickClock() {
  const now = new Date();
  document.getElementById('clock-time').textContent = now.toLocaleTimeString();
  document.getElementById('clock-date').textContent = now.toLocaleDateString(undefined, {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
  });
}

function renderStats(clients) {
  const total = clients.length;
  const active = clients.filter((c) => c.status !== 'Won' && c.status !== 'Lost').length;
  const wonRevenue = clients
    .filter((c) => c.status === 'Won')
    .reduce((sum, c) => sum + c.dealValue, 0);
  const newThisWeek = clients.filter(
    (c) => (Date.now() - new Date(c.createdAt)) / 86400000 <= 7
  ).length;

  document.getElementById('stat-total').textContent = total;
  document.getElementById('stat-active').textContent = active;
  document.getElementById('stat-revenue').textContent = formatCurrency(wonRevenue);
  document.getElementById('stat-new').textContent = newThisWeek;
}

function renderPipeline(clients) {
  const counts = { Lead: 0, Contacted: 0, Won: 0, Lost: 0 };
  clients.forEach((c) => { if (counts[c.status] !== undefined) counts[c.status]++; });
  const max = Math.max(1, ...Object.values(counts));

  const container = document.getElementById('pipeline-overview');
  container.innerHTML = STATUS_ORDER.map((status) => {
    const count = counts[status];
    const pct = Math.round((count / max) * 100);
    return `
      <div class="pipeline-item">
        <span class="pname">${status}</span>
        <span class="ptrack"><span class="pfill" style="width:${pct}%; background:${STATUS_COLOR_VAR[status]};"></span></span>
        <span class="pcount">${count}</span>
      </div>`;
  }).join('');
}

function renderRecent(clients) {
  const recent = clients
    .slice()
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 5);

  const container = document.getElementById('recent-clients');
  if (recent.length === 0) {
    container.innerHTML = '<p class="state-msg">No clients yet.</p>';
    return;
  }

  container.innerHTML = recent.map((c) => `
    <div class="recent-row">
      <img class="avatar" src="${c.image}" alt="">
      <div class="who">
        <div class="n">${escapeHtml(c.name)}</div>
        <div class="c">${escapeHtml(c.company || '—')}</div>
      </div>
      <span class="badge st-${c.status.toLowerCase()}">${c.status}</span>
      <span class="date">${new Date(c.createdAt).toLocaleDateString()}</span>
    </div>
  `).join('');
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str == null ? '' : str;
  return div.innerHTML;
}

async function initDashboard() {
  renderGreeting();
  tickClock();
  setInterval(tickClock, 1000);

  try {
    const { clients } = await loadClients();
    renderStats(clients);
    renderPipeline(clients);
    renderRecent(clients);
  } catch (err) {
    showToast('Could not load dashboard data.', 'error');
  }
}

document.addEventListener('DOMContentLoaded', initDashboard);
